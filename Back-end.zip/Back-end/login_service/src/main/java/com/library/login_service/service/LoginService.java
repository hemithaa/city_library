package com.library.login_service.service;

import com.library.login_service.dto.LoginRequest;
import com.library.login_service.entity.Reader;
import java.util.Map;

public interface LoginService {
    Map<String, String> login(LoginRequest request);
    String validateToken(String token);
    String signUp(Reader reader);
}