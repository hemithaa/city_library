package com.library.login_service.service;

import com.library.login_service.dto.LoginRequest;
import com.library.login_service.entity.Reader;
import com.library.login_service.exception.CustomException;
import com.library.login_service.repository.ReaderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.HashMap;
import java.util.Map;

@Service
public class LoginServiceImpl implements LoginService {
    
    @Autowired 
    private AuthenticationManager authenticationManager;
    
    @Autowired 
    private JwtTokenService jwtTokenService;
    
    @Autowired 
    private ReaderRepository readerRepository;
    
    @Autowired 
    private PasswordEncoder passwordEncoder;

    @Override
    public Map<String, String> login(LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    request.getId(),
                    request.getPassword()
                )
            );
            
            SecurityContextHolder.getContext().setAuthentication(authentication);
            
            String role = authentication.getAuthorities().stream()
                .findFirst()
                .map(r -> r.getAuthority())
                .orElseThrow(() -> new CustomException("No role assigned"));
            
            String token = jwtTokenService.generateToken(request.getId(), role);
            
            Map<String, String> response = new HashMap<>();
            response.put("token", token);
            response.put("role", role);
            return response;
        } catch (BadCredentialsException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid credentials");
        }
    }

    @Override
    public String signUp(Reader reader) {
        if (readerRepository.findByReaderId(reader.getReaderId()).isPresent()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Reader ID already exists");
        }
        reader.setPassword(passwordEncoder.encode(reader.getPassword()));
        readerRepository.save(reader);
        return "Signup successful!";
    }

    @Override
    public String validateToken(String token) {
        try {
            return jwtTokenService.validateToken(token);
        } catch (Exception e) { 
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid token");
        }
    }
}