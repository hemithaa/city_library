package com.library.login_service.service;

import com.library.login_service.entity.Librarian;
import com.library.login_service.entity.Reader;
import com.library.login_service.repository.LibrarianRepository;
import com.library.login_service.repository.ReaderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    @Autowired
    private LibrarianRepository librarianRepository;
    
    @Autowired
    private ReaderRepository readerRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Checks in librarian table first
        Optional<Librarian> librarian = librarianRepository.findByLibrarianId(username);
        if (librarian.isPresent()) {
            return new User(
                librarian.get().getLibrarianId(),
                librarian.get().getPassword(),
                Collections.singletonList(new SimpleGrantedAuthority("LIBRARIAN"))
            );
        }
        
        // If not found in librarian table, it checks in reader table
        Optional<Reader> reader = readerRepository.findByReaderId(username);
        if (reader.isPresent()) {
            return new User(
                reader.get().getReaderId(),
                reader.get().getPassword(),
                Collections.singletonList(new SimpleGrantedAuthority("READER"))
            );
        }
        
        throw new UsernameNotFoundException("User not found with username: " + username);
    }
}