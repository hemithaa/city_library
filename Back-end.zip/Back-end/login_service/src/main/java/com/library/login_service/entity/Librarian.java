package com.library.login_service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_librarian")
public class Librarian {
    @Id
    @Column(name = "LibrarianID")
    private String librarianId;

    private String password;
}