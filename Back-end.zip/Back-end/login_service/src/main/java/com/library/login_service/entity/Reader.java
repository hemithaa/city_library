package com.library.login_service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_reader")
public class Reader {
    @Id
    @Column(name = "ReaderID")
    @NotBlank(message = "Reader ID cannot be blank")
    @Size(min = 3, max = 20, message = "Reader ID must be 3-20 characters")
    private String readerId;

    @NotBlank(message = "Password cannot be blank")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String password;
}