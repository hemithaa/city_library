package com.library.login_service.controller;

import com.library.login_service.dto.LoginRequest;
import com.library.login_service.entity.Reader;
import com.library.login_service.service.LoginService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired 
    private LoginService loginService;

    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(loginService.login(request));
    }

    @GetMapping("/validate")
    public ResponseEntity<String> validateToken(@RequestParam String token) {
        return ResponseEntity.ok(loginService.validateToken(token));
    }

    @PostMapping("/signUp")
    public ResponseEntity<String> signUp(@Valid @RequestBody Reader reader) {
        return ResponseEntity.ok(loginService.signUp(reader));
    }
}