package com.library.login_service.repository;

import com.library.login_service.entity.Reader;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ReaderRepository extends JpaRepository<Reader, String>
{
	Optional<Reader> findByReaderId(String readerId);
}
