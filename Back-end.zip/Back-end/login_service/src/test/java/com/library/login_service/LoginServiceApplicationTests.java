package com.library.login_service;

import com.library.login_service.dto.LoginRequest;
import com.library.login_service.entity.Reader;
import com.library.login_service.repository.ReaderRepository;
import com.library.login_service.service.JwtTokenService;
import com.library.login_service.service.LoginServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoginServiceTests {

    @Mock 
    private ReaderRepository readerRepository;
    
    @Mock 
    private JwtTokenService jwtTokenService;
    
    @Mock 
    private PasswordEncoder passwordEncoder;
    
    @Mock 
    private AuthenticationManager authenticationManager;
    
    @Mock 
    private Authentication authentication;

    @InjectMocks 
    private LoginServiceImpl loginService;

    // Test1️ - Login test
    @Test
    void testLogin() {
        doReturn(authentication).when(authenticationManager)
                .authenticate(any(UsernamePasswordAuthenticationToken.class));
        doReturn(List.of(new SimpleGrantedAuthority("ROLE_READER")))
                .when(authentication).getAuthorities();
        doReturn("jwt123").when(jwtTokenService)
                .generateToken(eq("user"), any());

        var result = loginService.login(new LoginRequest("user", "pass"));

        assertEquals("jwt123", result.get("token"));
    }

    // Test2️ - Signup test
    @Test
    void testSignup() {
        doReturn(Optional.empty()).when(readerRepository).findByReaderId("newUser");
        doReturn("enc").when(passwordEncoder).encode("pass");

        String result = loginService.signUp(new Reader("newUser", "pass"));

        assertEquals("Signup successful!", result);
        verify(readerRepository).save(any(Reader.class));
    }

    // Test3️ - Validate token test
    @Test
    void testValidateToken() {
        doReturn("READER").when(jwtTokenService).validateToken("good");
        assertEquals("READER", loginService.validateToken("good"));

        doThrow(new RuntimeException("Invalid"))
                .when(jwtTokenService).validateToken("bad");
        assertThrows(RuntimeException.class, () -> loginService.validateToken("bad"));
    }
}
