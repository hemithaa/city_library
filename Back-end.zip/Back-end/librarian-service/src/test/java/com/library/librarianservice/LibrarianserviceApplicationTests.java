package com.library.librarianservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.library.librarianservice.models.dao.services.LibrarianService;
import com.library.librarianservice.models.pojos.BookIssue;
import com.library.librarianservice.models.repositories.LibrarianRepo;

@SpringBootTest
class LibrarianserviceApplicationTests {

	@Autowired
	public LibrarianService librarianService;
	
	@MockBean
	LibrarianRepo librarianRepo;
	
	@Test
	public void getAllIssuedBooksTest() {
		when(librarianRepo.findAll()).thenReturn(
				Stream.of(
						new BookIssue(1, "R001", "B001", LocalDate.parse("2025-08-17"), LocalDate.parse("2025-08-20"), "Pending"),
						new BookIssue(2, "R002", "B002", LocalDate.parse("2025-08-15"), LocalDate.parse("2025-08-18"), "Pending"),
						new BookIssue(3, "R003", "B003", LocalDate.parse("2025-08-16"), LocalDate.parse("2025-08-19"), "Pending"),
						new BookIssue(4, "R004", "B004", LocalDate.parse("2025-08-12"), LocalDate.parse("2025-08-15"), "returned")
						).collect(Collectors.toList()));
		
		
		assertEquals(librarianService.getAllIssuedBooks().size(), 4);
		
	}
	
	@Test
	public void saveIssuedBookTest() {
		BookIssue B = new BookIssue(1, "R001", "B001", LocalDate.parse("2025-08-17"), LocalDate.parse("2025-08-20"), "Pending");
		when(librarianRepo.save(B)).thenReturn(B);
		BookIssue bi = librarianService.saveIssuedBook(B);
		assertEquals(B, bi);
	}
	
	@Test
	public void getIssueBooksTest() {
		String readerId = "R001";
		when(librarianRepo.findByReaderId(readerId)).thenReturn(
				Stream.of(
				new BookIssue(1, "R001", "B001", LocalDate.parse("2025-08-17"), LocalDate.parse("2025-08-20"), "Pending"),
				new BookIssue(1, "R001", "B002", LocalDate.parse("2025-08-17"), LocalDate.parse("2025-08-20"), "Pending")
				).collect(Collectors.toList()));
		
		assertEquals(librarianService.getIssueBooks(readerId).size(), 2);
		
	}
	
}