package com.library.librarianservice.models.Exception;

public class NotFoundException extends RuntimeException
{
	public NotFoundException(String msg)
	{
		super(msg);
	}

}
