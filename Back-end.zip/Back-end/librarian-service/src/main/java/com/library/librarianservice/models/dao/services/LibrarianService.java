package com.library.librarianservice.models.dao.services;

import java.util.List;

import com.library.librarianservice.models.Exception.NotFoundException;
import com.library.librarianservice.models.pojos.BookIssue;


public interface LibrarianService 
{	
	List<BookIssue> getAllIssuedBooks();
	BookIssue saveIssuedBook(BookIssue bookDetails);
	BookIssue updateIssuedBook(BookIssue bookDetails, int id);
	String markReturned(int issueId);
	BookIssue issueBook(BookIssue bookDetails) throws NotFoundException;
	List<BookIssue> getIssueBooks(String readerId);
	boolean checkIfReaderExists(String readerId);
}
