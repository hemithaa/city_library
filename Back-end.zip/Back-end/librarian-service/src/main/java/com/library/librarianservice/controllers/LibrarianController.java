package com.library.librarianservice.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.librarianservice.models.dao.services.LibrarianService;
import com.library.librarianservice.models.pojos.BookIssue;

@RestController
@RequestMapping("/librarian")
public class LibrarianController {
	
	@Autowired
	LibrarianService libraryServiceImpl;
	
	//find out all issued books
	@GetMapping("/viewIssuedBooks")
	public ResponseEntity<?> viewIssuedBooks()
	{
		List<BookIssue> list = libraryServiceImpl.getAllIssuedBooks();
		if(list.size() == 0)
		{
			return new ResponseEntity<String>("No records exists", HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity<List<BookIssue>>(list,HttpStatus.OK);
		}
	}
	//add issue books in the database
	@PostMapping("/issueBook")
    public ResponseEntity<BookIssue> issueBook(@RequestBody BookIssue issue) 
	{
        BookIssue issuedBook = libraryServiceImpl.issueBook(issue);
        return ResponseEntity.ok(issuedBook);
    }
	
	
	@PutMapping("/updateIssuedBook/{id}")
	public ResponseEntity<?> updateIssueBook(@RequestBody BookIssue bookDetails,@PathVariable("id") int id)
	{
		BookIssue bookIssue = libraryServiceImpl.updateIssuedBook(bookDetails, id);
		if(bookIssue == null) 
		{
			return new ResponseEntity<String>("Record does not exists", HttpStatus.BAD_REQUEST);
		}
		else
		{
			return new ResponseEntity<BookIssue>(bookIssue,HttpStatus.ACCEPTED);
		}
	}
	
	//this updates the values when clicked on the button in front-end
	@PutMapping("/markReturned/{issueId}")
	public ResponseEntity<String> markReturned(@PathVariable int issueId)
	{
		String result=libraryServiceImpl.markReturned(issueId);
		if(result=="Issue not found")
		{
			 ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
		}
		return ResponseEntity.ok(result);
	}
	
	@GetMapping("/getIssuedBook/{readerId}")
	public ResponseEntity<List<BookIssue>> getIssueBooks(@PathVariable String readerId)
	{
		return ResponseEntity.ok(libraryServiceImpl.getIssueBooks(readerId));
	}
	
	@GetMapping("/exists/{readerId}")
    public ResponseEntity<Boolean> checkIfReaderExists(@PathVariable String readerId) 
	{
        boolean exists = libraryServiceImpl.checkIfReaderExists(readerId);
        return ResponseEntity.ok(exists);
    }
}









