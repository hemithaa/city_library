package com.library.librarianservice.models.pojos;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class BookIssue {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int issueId;
	@Column(length = 30)
	private String readerId;
	@Column(length = 30)
	private String bookId;
	private LocalDate borrowDate;
	private LocalDate returnDate;
	private String status;
}










