package com.library.librarianservice.models.dao.serviceImpl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.library.librarianservice.models.Exception.NotFoundException;
import com.library.librarianservice.models.dao.services.LibrarianService;
import com.library.librarianservice.models.pojos.BookIssue;
import com.library.librarianservice.models.repositories.LibrarianRepo;


@Service
public class LibrarianServiceImpl implements LibrarianService{
	
	@Autowired
	LibrarianRepo librarianRepo;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public List<BookIssue> getAllIssuedBooks() 
	{
		return librarianRepo.findAll();
	}

	@Override
	public BookIssue saveIssuedBook(BookIssue bookDetails)
	{
		Optional<BookIssue> OE = librarianRepo.findById(bookDetails.getIssueId());
		if(OE.isPresent())
		{
			return null;
		}
		else
		{
			return librarianRepo.save(bookDetails);
		}
	}
	@Override
	public BookIssue updateIssuedBook(BookIssue bookDetails, int id)
	{
		Optional<BookIssue> BookIssue = librarianRepo.findById(id);	
		if(BookIssue.isPresent()) 
		{
			return librarianRepo.save(bookDetails);
		}
		else
		{
			return null;
		}
		
	}
	
	public String markReturned(int issueId)
	{
	    Optional<BookIssue> issueOpt = librarianRepo.findById(issueId);
	    if (issueOpt.isPresent())
	    {
	        BookIssue issue = issueOpt.get();
	        issue.setStatus("Returned");
	        librarianRepo.save(issue);

	        // Update book count in book service
	        restTemplate.put("http://localhost:8081/api/books/incrementCount/" + issue.getBookId(), null);

	        return "Book marked as returned";
	    } 
	    else
	    {
	        return "Issue not found";
	    }
	}
	
    public BookIssue issueBook(BookIssue request)throws NotFoundException
    {
    	LocalDate today = LocalDate.now();
        LocalDate threeDaysLater = today.plusDays(3);
        ResponseEntity<Boolean> readerExists =
                restTemplate.getForEntity("http://localhost:8082/readers/exists/"+request.getReaderId(),Boolean.class);
        if (readerExists.getBody() == null || !readerExists.getBody()) 
        {
            throw new NotFoundException("Reader ID does not exist.");
        }
        ResponseEntity<Boolean> bookExists =
                restTemplate.getForEntity("http://localhost:8081/api/books/exists/"+request.getBookId(),Boolean.class);
        if (bookExists.getBody() == null || !bookExists.getBody())
        {
            throw new NotFoundException("Book ID does not exist.");
        }
        BookIssue issue = new BookIssue();
        issue.setReaderId(request.getReaderId());
        issue.setBookId(request.getBookId());
        issue.setBorrowDate(today);
        issue.setReturnDate(threeDaysLater);
        System.out.println(LocalDate.now().plusDays(3));
        issue.setStatus("Pending");
        restTemplate.put("http://localhost:8081/api/books/decrement/" + request.getBookId(),null);
        return librarianRepo.save(issue);
    }
    public List<BookIssue> getIssueBooks(String readerId)
    {
    	return librarianRepo.findByReaderId(readerId);
    }
    @Override
    public boolean checkIfReaderExists(String readerId) 
    {
        return librarianRepo.existsByReaderId(readerId);
    }

}






