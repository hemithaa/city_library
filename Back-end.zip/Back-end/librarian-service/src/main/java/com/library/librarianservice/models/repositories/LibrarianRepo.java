package com.library.librarianservice.models.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.library.librarianservice.models.pojos.BookIssue;

@Repository
public interface LibrarianRepo extends  JpaRepository<BookIssue, Integer>
{	
	List<BookIssue> findByReaderId(String readerId);
	boolean existsByReaderId(String readerId);
}
