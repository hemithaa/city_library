package com.library.reader_service;

import com.library.reader_service.client.BookClient;
import com.library.reader_service.controller.ReaderController;
import com.library.reader_service.dto.BookDTO;
import com.library.reader_service.model.Reader;
import com.library.reader_service.service.ReaderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class ReaderServiceApplicationTests {

    @Mock
    private BookClient bookClient;

    @Mock
    private ReaderService readerService;

    @InjectMocks
    private ReaderController readerController;

    private Reader reader;
    private BookDTO book;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        reader = new Reader("R1", "Alice", "alice@mail.com", "1234567890", "NYC", "Downtown");
        book = new BookDTO("B1", "Java Basics", "Programming", "James", "AVAILABLE", 5, "TechPub");
    }

    /** 1. Register a reader */
    @Test
    void testRegisterReader() {
        when(readerService.saveReader(any(Reader.class))).thenReturn(reader);

        ResponseEntity<Reader> response = readerController.registerReader(reader);

        assertNotNull(response.getBody());
        assertEquals("Alice", response.getBody().getName());
    }

    /** 2. Get all readers */
    @Test
    void testGetAllReaders() {
        when(readerService.getAllReaders()).thenReturn(Arrays.asList(reader));

        ResponseEntity<List<Reader>> response = readerController.getAllReaders();

        assertEquals(1, response.getBody().size());
        assertEquals("Alice", response.getBody().get(0).getName());
    }

    /** 3. Check if reader exists */
    @Test
    void testReaderExists() {
        when(readerService.existsById("R1")).thenReturn(true);

        ResponseEntity<Boolean> response = readerController.readerExists("R1");

        assertTrue(response.getBody());
    }

    /** 4. Search books by name */
    @Test
    void testSearchBooksByName() {
        when(bookClient.searchBooksByName("Java Basics")).thenReturn(Arrays.asList(book));

        List<BookDTO> result = readerController.searchBooksByName("Java Basics");

        assertEquals(1, result.size());
        assertEquals("Java Basics", result.get(0).getName());
    }
}
