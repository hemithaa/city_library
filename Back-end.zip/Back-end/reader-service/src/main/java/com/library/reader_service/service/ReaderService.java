package com.library.reader_service.service;

import com.library.reader_service.model.Reader;
import com.library.reader_service.repository.ReaderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReaderService {

    @Autowired
    private ReaderRepository readerRepository;

    public List<Reader> getAllReaders() 
    {
        return readerRepository.findAll();
    }
    public Optional<Reader> getReaderById(String id)
    {
        return readerRepository.findById(id);
    }
    public Reader saveReader(Reader reader)
    {
        return readerRepository.save(reader);
    }
    public void deleteReader(String id)
    {
        readerRepository.deleteById(id);
    }
    public boolean existsById(String readerID)
    {
        return readerRepository.existsById(readerID);
    }
}
