package com.library.reader_service.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.library.reader_service.dto.BookDTO;

import java.util.Arrays;
import java.util.List;

@Service
public class BookClient {

    @Autowired
    private RestTemplate restTemplate;

    private static final String BOOK_SERVICE_URL = "http://localhost:8081/api/books"; 

    public List<BookDTO> getAllBooks() 
    {
        return Arrays.asList(restTemplate.getForObject(BOOK_SERVICE_URL, BookDTO[].class));
    }

    public List<BookDTO> searchBooksByName(String name)
    {
        return Arrays.asList(restTemplate.getForObject(BOOK_SERVICE_URL + "/search?name=" + name, BookDTO[].class));
    }

    public List<BookDTO> searchBooksByAuthor(String author)
    {
        return Arrays.asList(restTemplate.getForObject(BOOK_SERVICE_URL + "/search?author=" + author, BookDTO[].class));
    }
}
