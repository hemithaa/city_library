package com.library.reader_service.controller;

import com.library.reader_service.client.*;
import com.library.reader_service.dto.*;
import com.library.reader_service.model.Reader;
import com.library.reader_service.service.ReaderService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/readers")
public class ReaderController {

	@Autowired
	private BookClient bookClient;
	
	@Autowired
	private ReaderService readerService;

	@GetMapping("/searchBooksByName")
	public List<BookDTO> searchBooksByName(@RequestParam String name) {
	    return bookClient.searchBooksByName(name);
	}

	@GetMapping("/searchBooksByAuthor")
	public List<BookDTO> searchBooksByAuthor(@RequestParam String author) {
	    return bookClient.searchBooksByAuthor(author);
	}

	@GetMapping("/allBooks")
	public List<BookDTO> getAllBooks()
	{
	    return bookClient.getAllBooks();
	}
	@GetMapping("/exists/{readerID}")
    public ResponseEntity<Boolean> readerExists(@PathVariable String readerID) 
	{
        boolean exists = readerService.existsById(readerID);
        return ResponseEntity.ok(exists);
    }
	
	@PostMapping
    public ResponseEntity<Reader> registerReader(@RequestBody Reader reader) {
        Reader savedReader = readerService.saveReader(reader);
        return ResponseEntity.ok(savedReader);
    }
	
	@GetMapping
    public ResponseEntity<List<Reader>> getAllReaders()
	{
        List<Reader> readers = readerService.getAllReaders();
        return ResponseEntity.ok(readers);
    }

}
