package com.library.reader_service.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Reader {

    @Id
    private String readerId;
    private String name;
    private String email;
    private String phoneNo;
    private String city;
    private String location;
}
