package com.library.book.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.library.book.model.Book;

@Repository
public interface BookRepository extends JpaRepository<Book,String> 
{
	boolean existsByName(String name);
	
    List<Book> findByNameContainingIgnoreCase(String name);

    List<Book> findByAuthorNameContainingIgnoreCase(String authorName);
}
