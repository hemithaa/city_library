package com.library.book.controller;

import com.library.book.model.Book;
import com.library.book.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController 
{

    @Autowired
    private BookService bookServiceImpl;

    @GetMapping
    public List<Book> getAllBooks()
    {
        return bookServiceImpl.getAllBooks();
    }

    @GetMapping("/{bookID}")
    public ResponseEntity<Book> getBookById(@PathVariable String bookID) 
    {
        return bookServiceImpl.getBookById(bookID)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    
    
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book)
    {
        Book saved = bookServiceImpl.addBook(book);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("updateCount/{bookId}")
    public ResponseEntity<Book> updateBook(@PathVariable String bookID,@RequestBody Book updatedBook) 
    {
            Book updated = bookServiceImpl.updateBook(bookID,updatedBook.getBookCount());
            return ResponseEntity.ok(updated);
    }
    @DeleteMapping("/{bookID}")
    public ResponseEntity<Void> deleteBook(@PathVariable String bookID)
    {
        	bookServiceImpl.deleteBook(bookID);
            return ResponseEntity.noContent().build();
    }
    @GetMapping("/search")
    public List<Book> searchBooks(@RequestParam(required = false) String name,
                                  @RequestParam(required = false) String author) 
    {
        if (name != null && !name.isBlank()) 
        {
            return bookServiceImpl.searchBooksByName(name);
        }
        else if (author != null && !author.isBlank())
        {
            return bookServiceImpl.searchBooksByAuthor(author);
        }
        else
        {
            return bookServiceImpl.getAllBooks();
        }
    }
    @PutMapping("/incrementCount/{bookId}")
    public ResponseEntity<String> incrementBookCount(@PathVariable String bookId) 
    {
    	bookServiceImpl.incrementBookCount(bookId);
        return ResponseEntity.ok("Book count incremented for book ID: " + bookId);
    }
    @PutMapping("/decrement/{bookId}")
    public ResponseEntity<Void> decrementBookCount(@PathVariable String bookId) 
    {
    	bookServiceImpl.decrementBookCount(bookId);
        return ResponseEntity.ok().build();
    }
    @GetMapping("/exists/{bookID}")
    public ResponseEntity<Boolean> bookExists(@PathVariable String bookID) {
        boolean exists = bookServiceImpl.existsById(bookID);
        return ResponseEntity.ok(exists);
    }
}