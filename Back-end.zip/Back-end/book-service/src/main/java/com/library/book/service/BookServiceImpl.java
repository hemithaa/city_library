package com.library.book.service;

import com.library.book.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.library.book.Exceptions.*;
import java.util.List;
import java.util.Optional;

import com.library.book.dao.BookRepository;
@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;
    
    
    public List<Book> getAllBooks() 
    {
        return bookRepository.findAll();
    }
    public Optional<Book> getBookById(String bookID)
    {
        return bookRepository.findById(bookID);
    }
    public Book addBook(Book book)
    {
        return bookRepository.save(book);
    }
    public Book updateBook(String bookID,int bookCount) 
    {
        return bookRepository.findById(bookID).map(existingBook -> {
            existingBook.setBookCount(bookCount);
            return bookRepository.save(existingBook);
        }).orElseThrow(() -> new BookNotFoundException("Book not found with ID: " + bookID));
    }
    public void deleteBook(String bookID)
    {
        if (!bookRepository.existsById(bookID))
        {
            throw new BookNotFoundException("Book not found with ID: " + bookID);
        }
        bookRepository.deleteById(bookID);
    }
    public List<Book> searchBooksByName(String name)
    {
        return bookRepository.findByNameContainingIgnoreCase(name);
    }
    public List<Book> searchBooksByAuthor(String authorName) 
    {
        return bookRepository.findByAuthorNameContainingIgnoreCase(authorName);
    }
    public void incrementBookCount(String bookId)
    {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException("Book not found with ID: " + bookId));
        
        book.setBookCount(book.getBookCount() + 1);
        bookRepository.save(book);
    }
    
    public void decrementBookCount(String bookId) 
    {
        Book book = bookRepository.findById(bookId)
                     .orElseThrow(() -> new BookNotFoundException("Book not found"));
        if (book.getBookCount() <= 0) 
        {
            throw new IllegalStateException("Book count is already 0");
        }
        book.setBookCount(book.getBookCount() - 1);
        bookRepository.save(book);
    }
    
    @Override
    public boolean existsById(String bookID) {
        return bookRepository.existsById(bookID);
    }
}