package com.library.book.service;

import java.util.List;
import java.util.Optional;

import com.library.book.model.Book;

public interface BookService 
{
	List<Book> getAllBooks();
	Optional<Book> getBookById(String bookID);
	Book addBook(Book book);
	Book updateBook(String bookID, int bookCount);
	void deleteBook(String bookID);
	List<Book> searchBooksByName(String name);
	List<Book> searchBooksByAuthor(String authorName);
	void incrementBookCount(String bookId);
	boolean existsById(String bookID);
	void decrementBookCount(String bookId);
}