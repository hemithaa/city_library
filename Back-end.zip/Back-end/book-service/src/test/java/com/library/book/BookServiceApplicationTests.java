package com.library.book;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.library.book.dao.BookRepository;
import com.library.book.model.Book;
import com.library.book.service.BookService;

import jakarta.persistence.Id;

@SpringBootTest
class BookServiceApplicationTests {

	@Autowired
	public BookService bookServiceImpl;
	
	@MockBean
	BookRepository bookRepository;
	
	@Test
	public void getAllBooksTest() {
		when(bookRepository.findAll()).thenReturn(
			Stream.of(
				new Book("B001","Sitaara","Fiction","Chethan","Available",12,"Disha"),
				new Book("B002","The Wings of Fire","AutoBiography","Abdul Kalam","Available",15,"Disha"),
				new Book("B003","Attitude is Everything","Self Help","Robinson","Available",2,"Collins")
				).collect(Collectors.toList()));
		
		assertEquals(bookServiceImpl.getAllBooks().size(),3);
		
	}
	
	@Test
	public void getBookByIdTest() {
		String bookId = "B001";
		when(bookRepository.findById(bookId)).thenReturn(
				Optional.of( new Book("B001","Sitaara","Fiction","Chethan","Available",12,"Disha")));
		
		Optional<Book> B = bookServiceImpl.getBookById(bookId);
		
		assertEquals("Sitaara",B.get().getName());
		assertEquals("Fiction", B.get().getCategory());
		assertEquals("B001", B.get().getBookID());
	}
	
	@Test
	public void addBookTest() {
		Book B = new Book("B001","Sitaara","Fiction","Chethan","Available",12,"Disha");
		when(bookRepository.save(B)).thenReturn(B);
		assertEquals(bookServiceImpl.addBook(B), B);
	}
	
	@Test
	public void searchByBookNameTest() {
		String name = "Attitude is Everything";
		when(bookRepository.findByNameContainingIgnoreCase(name)).thenReturn(
				Stream.of(
						new Book("B003","Attitude is Everything","Self Help","Robinson","Available",2,"Collins")
						).collect(Collectors.toList()));
		
		assertEquals(bookServiceImpl.searchBooksByName(name).size(),1);
		
	}

}