import React, { useState } from 'react';
import './Search.css';

export default function Search() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBy, setFilterBy] = useState('name');
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchBooks = async (query) => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`http://localhost:8080/api/books/search${query}`);
      if (!response.ok) throw new Error('Failed to fetch books');
      const data = await response.json();
      setBooks(data);
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (!searchTerm.trim())
      {
        setError("Search cannot be empty");
        return;
      }  

    const query =
      filterBy === 'name'
        ? `?name=${encodeURIComponent(searchTerm.trim())}`
        : `?author=${encodeURIComponent(searchTerm.trim())}`;
    fetchBooks(query);
  };

  const handleLoadAll = () => {
    fetchBooks('');
    setSearchTerm('');
  };

  return (
    <div className="search-container">
      <button type="button" onClick={() => window.history.back()}
            style={{position: 'fixed',top: '20px',left: '20px',background: '#e74c3c',color: 'white',padding: '8px 12px',borderRadius: '5px',border: 'none',cursor: 'pointer',zIndex: 1000, }}
      >
        Go Back
      </button>
      <h2>Search Books</h2>
      <form onSubmit={handleSearch} className="search-form">
        <select value={filterBy} onChange={(e) => setFilterBy(e.target.value)}>
          <option value="name">Search by Name</option>
          <option value="author">Search by Author</option>
        </select>
        <input
          type="text"
          placeholder={filterBy === 'name' ? 'Enter Book Name' : 'Enter Author Name'}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button type="submit" disabled={loading}>Search</button>
        <button type="button" onClick={handleLoadAll} disabled={loading} style={{ marginLeft: '10px' }}>
          Load All
        </button>
      </form>

      {loading && <p>Loading books...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div className="books-grid">
        {books.length === 0 && !loading && <p>No books found.</p>}
        {books.filter((book) => book.bookCount > 0)
          .map((book) => (
          <div key={book.bookID} className="book-card">
            <div className="card-main">
              <strong>{book.name}</strong>
              <p>{book.authorName}</p>
            </div>
            <div className="card-overlay">
              <p><strong>Category:</strong> {book.category}</p>
              <p><strong>Publisher:</strong> {book.publisher}</p>
              <p><strong>Status:</strong> {book.bookStatus}</p>
              <p><strong>Count:</strong> {book.bookCount}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
