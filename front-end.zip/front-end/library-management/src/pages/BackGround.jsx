import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three"; 
import NET from "vanta/dist/vanta.net.min"; 

export default function VantaBackground() {
  const [vantaEffect, setVantaEffect] = useState(null);
  const vantaRef = useRef(null);

  useEffect(() => {
    if (!vantaEffect) {
      setVantaEffect(
        NET({
          el: vantaRef.current,
          mouseControls: true,
          touchControls: true,
          gyroControls: false,
          minHeight: 200.0,
          minWidth: 200.0,
          scale: 1.0,
          scaleMobile: 1.0,
          color: 0x00bcd4,
          points: 15.0,
          maxDistance: 22.0,
        })
      );
    }

    return () => {
      if (vantaEffect) vantaEffect.destroy();
    };
  }, [vantaEffect]);

  return (
    <div
      ref={vantaRef}
      style={{ width: "100%", height: "100vh" }} 
    >
      <h1 style={{ position: "relative", color: "white", textAlign: "center", paddingTop: "40vh" }}>
        My Library Management System
      </h1>
    </div>
  );
}
