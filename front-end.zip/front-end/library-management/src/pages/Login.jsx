import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import "./Login.css";

export default function Login()
{
    const[id,SetId]=useState('');
    const[password,SetPassword]=useState('');
    const[message,setMessage]=useState('');
    const[errors,SetErrors]=useState({});
    const navigate=useNavigate();

    useEffect(() => {
    const token = sessionStorage.getItem('token');
    if (token) 
    {
      const role = sessionStorage.getItem('role');
      if (role === 'LIBRARIAN') {
        navigate('/librarian');
      } else {
        navigate('/reader');
      }
    }
  }, [navigate]);



    const handleSubmit=async(e)=>
        {
            e.preventDefault();
            let forErrors={ };
            if(id.trim().length==0) forErrors.id="Id is required";
            if(password.trim().length==0) forErrors.password="Password is required";
            SetErrors(forErrors);
            if(Object.keys(forErrors).length==0)
            {
              try{
                const response=await fetch("http://localhost:8080/api/auth/login",
                {
                    method:'Post',
                    headers:
                    {
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id,password})
                })
                let data=await response.json();
                if(response.ok)
                {
                    sessionStorage.setItem("id",id);
                    sessionStorage.setItem("token",data.token);
                    sessionStorage.setItem("role",data.role);       
                    setMessage('');
                    if(data.role==="LIBRARIAN")
                        navigate('/librarian')
                    else
                        navigate("/reader")

                }
                else
                {
                    setMessage("Enter valid id or Password");
                }
              }
              catch
              {
                setMessage("Something went wrong try after some time")
              }
            }
        }
  return (
    <>
    <div>
      <div className="navbar">
        <div className="listell">
          <Link to="/">Home</Link>
        </div>
      </div>
    </div>
    <div className='form-wrapper'>
        <form onSubmit={handleSubmit} className='login-form'>
        <h2 className="form-title">Login Page</h2>

        <label className="form-label">Id</label>
        <input
          className="form-input"
          type="text"
          placeholder="Enter Id"
          value={id}
          onChange={(e) => SetId(e.target.value)}
        />
        <div className="error-space">
              {errors.id && <p className="error-signin">{errors.id}</p>}
        </div>
        <label className="form-label">Password</label>
        <input
          className="form-input"
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => SetPassword(e.target.value)}
          />
        <div className="error-space">
          {errors.password && <p className="error-signin">{errors.password}</p>}
        </div>

        <button className="submit-btn" type="submit">Submit</button>
        {message && <p className="message">{message}</p>}

        <p style={{ marginTop: "1rem" }}>
                        Not registered yet?{" "}
                        <Link to="/signup" style={{ color: "#00bcd4" }}>Sign up here</Link>
                    </p>
      </form>
    </div>
    </>
  )
}