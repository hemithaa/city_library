import React, { useState } from 'react';
import AddBook from './AddBook';
import RemoveBook from './RemoveBook';
import './Book.css';

export default function Book() {
  const [activeComponent, setActiveComponent] = useState("");

  return (
    <div className="book-container">
      <h2 className="book-title">📚 Manage Books</h2>
      
      <button
        className="book-btn"
        onClick={() => setActiveComponent('add')}
      >
        ➕Add Book
      </button>
      
      <button
        className="book-btn"
        onClick={() => setActiveComponent('remove')}
      >
        ❌Remove Book
      </button>

      <div className="book-content">
        {activeComponent === 'add' && <AddBook />}
        {activeComponent === 'remove' && <RemoveBook />}
        {!activeComponent && <p>Select an action above.</p>}
      </div>
    </div>
  );
}
