import React, { useState } from 'react';
import "./RemoveBook.css";
export default function RemoveBook() 
{
  const [id, setId] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const handleRemove = async (e) => {
    e.preventDefault();

    if (!id.trim()) {
      setError('Book ID is required');
      setMessage('');
      return;
    }

    setError('');

    try {
      const token = sessionStorage.getItem('token'); // assuming token is stored in localStorage

      const response = await fetch(`http://localhost:8080/api/books/${id}`,
      {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`, // attach token
        },
      });

      if (response.ok) 
      {
        setMessage(`Book with ID "${id}" removed successfully.`);
        setId('');
      }
      else if (response.status === 401)
      {
        setMessage('Unauthorized. Please log in again.');
      }
      else
      {
        const data = await response.text();
        setMessage(data || 'Failed to remove book.');
      }
    }
    catch(error)
    {
      setMessage('Error removing book. Please try again later.');
    }
  };

  return (
    <div className="remove-book-container">
  <h2>Remove Book</h2>
  <form className="remove-book-form" onSubmit={handleRemove}>
    <div>
      <label className="remove-book-label">Book ID:</label>
      <input
        type="text"
        value={id}
        className="remove-book-input"
        onChange={(e) => setId(e.target.value)}
      />
      {error && <p className="remove-book-error">{error}</p>}
    </div>

    <button type="submit" className="remove-book-btn">Remove Book</button>
  </form>

    {message && <p className="remove-book-message">{message}</p>}
</div>
  );
}
