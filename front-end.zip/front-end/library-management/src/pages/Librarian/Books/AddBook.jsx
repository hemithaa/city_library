import React, { useState } from 'react';
import './AddBook.css';

export default function AddBook() {
  const [book, setBook] = useState({
    bookID: '',
    name: '',
    category: '',
    authorName: '',
    bookStatus: 'Available',
    bookCount: '',
    publisher: '',
  });

  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');

  const handleChange = e => {
    const { name, value } = e.target;
    setBook(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    let errs = {};
    if (!book.bookID.trim()) errs.bookID = 'Book ID is required';
    if (!book.name.trim()) errs.name = 'Book name is required';
    if (!book.category.trim()) errs.category = 'Category is required';
    if (!book.authorName.trim()) errs.authorName = 'Author name is required';
    if (!book.bookCount || isNaN(book.bookCount) || book.bookCount <= 0)
      errs.bookCount = 'Book count must be a positive number';
    if (!book.publisher.trim()) errs.publisher = 'Publisher is required';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async e => {
    e.preventDefault();

    if (!validate()) {
      setMessage('Please fill the above details.');
      return;
    }

    try {
      const token = sessionStorage.getItem('token'); 
      if (!token) {
        setMessage('Unauthorized: Please log in.');
        return;
      }

      const response = await fetch('http://localhost:8080/api/books', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(book),
      });

      if (response.ok) {
        setMessage('✅ Book added successfully!');
        setBook({
          bookID: '',
          name: '',
          category: '',
          authorName: '',
          bookStatus: 'Available',
          bookCount: '',
          publisher: '',
        });
        setErrors({});
      }
      else if (response.status === 401) {
        setMessage("❌ Unauthorized. Please log in again.");
      }
      else {
        setMessage("Failed to Add Book");
      }
    } catch (error) {
      setMessage("Something went wrong, check the details sent.");
    }
  };

  return (
    <div className="add-book-container">
      <h3 className="add-book-title">Add Book</h3>
      <form className="add-book-form" onSubmit={handleSubmit} noValidate>
        <input
          className="add-book-input"
          type="text"
          name="bookID"
          placeholder="Book ID"
          value={book.bookID}
          onChange={handleChange}
        />
        {errors.bookID && <p className="add-book-error">{errors.bookID}</p>}

        <input
          className="add-book-input"
          type="text"
          name="name"
          placeholder="Book Name"
          value={book.name}
          onChange={handleChange}
        />
        {errors.name && <p className="add-book-error">{errors.name}</p>}

        <input
          className="add-book-input"
          type="text"
          name="category"
          placeholder="Category"
          value={book.category}
          onChange={handleChange}
        />
        {errors.category && <p className="add-book-error">{errors.category}</p>}

        <input
          className="add-book-input"
          type="text"
          name="authorName"
          placeholder="Author Name"
          value={book.authorName}
          onChange={handleChange}
        />
        {errors.authorName && <p className="add-book-error">{errors.authorName}</p>}

        <input
          className="add-book-input"
          type="number"
          name="bookCount"
          placeholder="Count"
          value={book.bookCount}
          onChange={handleChange}
        />
        {errors.bookCount && <p className="add-book-error">{errors.bookCount}</p>}

        <input
          className="add-book-input"
          type="text"
          name="publisher"
          placeholder="Publisher"
          value={book.publisher}
          onChange={handleChange}
        />
        {errors.publisher && <p className="add-book-error">{errors.publisher}</p>}

        <button className="add-book-btn" type="submit">Add Book</button>
      </form>

      {message && <p className="add-book-message">{message}</p>}
    </div>
  );
}
