import React, { useState } from "react";
import './SearchReader.css';
export default function ReaderSearch() {
  const [searchReaderId, setSearchReaderId] = useState("");
  const [allReaders, setAllReaders] = useState([]);
  const [error, setError] = useState("");

  const token = sessionStorage.getItem("token");

  // Fetch all readers
  const handleFetchAll = async () => {
    try {
      const response = await fetch(`http://localhost:8080/readers`,
        {
        headers: { Authorization: `Bearer ${token}` },
        });
      if (!response.ok) throw new Error("Failed to fetch readers");

      const data = await response.json();
      setAllReaders(data);
      setError("");
    } catch (err) {
      setAllReaders([]);
      setError(err.message);
    }
  };

  // Filter readers locally by ID
  const filteredReaders = allReaders.filter(reader =>
    reader.readerId.toLowerCase().includes(searchReaderId.toLowerCase())
  );

  return (
    <div className="reader-info-container">
      <h2 className="reader-info-title">Reader Management</h2>

      <div style={{ margin: "15px 0" }}>
        <input
          type="text"
          placeholder="Search by Reader ID"
          value={searchReaderId}
          onChange={(e) => setSearchReaderId(e.target.value)}
          className="reader-info-filter"
        />
        <button onClick={handleFetchAll} style={{ marginLeft: "10px" }}>
          Fetch All
        </button>
      </div>

      {error && <div style={{ color: "red", marginTop: "10px" }}>{error}</div>}

      {/* All readers table */}
      {allReaders.length > 0 && (
        <table className="reader-info-table">
          <thead>
            <tr>
              <th>Reader ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>City</th>
              <th>Area</th>
            </tr>
          </thead>
          <tbody>
            {filteredReaders.length > 0 ? (
              filteredReaders.map((reader) => (
                <tr key={reader.readerId}>
                  <td>{reader.readerId}</td>
                  <td>{reader.name}</td>
                  <td>{reader.email}</td>
                  <td>{reader.phoneNo}</td>
                  <td>{reader.city}</td>
                  <td>{reader.location}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" style={{ textAlign: "center" }}>
                  No readers found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}
