import React, { useState } from 'react';
import RegisterReader from './RegisterReader';
import SearchReader from './SearchReader';
import './ReaderOperations.css';
export default function Reader() {
  const [activeComponent, setActiveComponent] = useState("");

  return (
    <div className="reader-container">
      <h2 className="reader-title">👤 Manage Readers</h2>

      <button
        className="reader-btn"
        onClick={() => setActiveComponent('Search')}>
        🔍 Search Reader
      </button>

      <button
        className="reader-btn"
        onClick={() => setActiveComponent('Register')}>
        📝 Register Reader
      </button>

      <div className="reader-content">
        {activeComponent === 'Search' && <SearchReader />}
        {activeComponent === 'Register' && <RegisterReader />}
        {!activeComponent && <p>Select an action above.</p>}
      </div>
    </div>
  );
}
