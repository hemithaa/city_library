import React, { useState } from "react";
import './RegisterReader.css';

export default function RegisterReader() {
  const [formData, setFormData] = useState({
    readerId: "",
    name: "",
    email: "",
    phoneNo: "",
    city: "",
    location: ""
  });

  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" }); // clear error on change
  };

  const validate = () => {
    const errs = {};
    if (!formData.readerId.trim()) errs.readerId = "Reader ID is required";
    if (!formData.name.trim()) errs.name = "Name is required";
    if (!formData.email.trim()) errs.email = "Email is required";
    if (!formData.phoneNo.trim()) errs.phoneNo = "Phone number is required";
    if (!formData.city.trim()) errs.city = "City is required";
    if (!formData.location.trim()) errs.location = "Area is required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleRegisterReader = async (e) => {
    e.preventDefault();
    if (!validate()) {
      setMessage("Please fill the details");
      return;
    }

    try {
      const token = sessionStorage.getItem("token");
      const response = await fetch("http://localhost:8080/readers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
        setMessage(`✅ Reader Registered! ID: ${data.readerId}`);
        setFormData({
          readerId: "",
          name: "",
          email: "",
          phoneNo: "",
          city: "",
          location: ""
        });
        setErrors({});
      } else {
        const errData = await response.json();
        setMessage(`❌ Error: ${errData.message || "Failed to register reader"}`);
      }
    } catch (error) {
      console.error(error);
      setMessage("❌ Error registering reader");
    }
  };

  return (
    <div className="register-reader-container">
      <h2 className="register-reader-title">Register Reader</h2>
      <form className="register-reader-form" onSubmit={handleRegisterReader} noValidate>
        <input
          className="register-reader-input"
          type="text"
          name="readerId"
          placeholder="Enter Reader Id"
          value={formData.readerId}
          onChange={handleChange}
        />
        {errors.readerId && <p className="register-reader-error">{errors.readerId}</p>}

        <input
          className="register-reader-input"
          type="text"
          name="name"
          placeholder="Name"
          value={formData.name}
          onChange={handleChange}
        />
        {errors.name && <p className="register-reader-error">{errors.name}</p>}

        <input
          className="register-reader-input"
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
        />
        {errors.email && <p className="register-reader-error">{errors.email}</p>}

        <input
          className="register-reader-input"
          type="text"
          name="phoneNo"
          placeholder="Phone Number"
          value={formData.phoneNo}
          onChange={handleChange}
        />
        {errors.phoneNo && <p className="register-reader-error">{errors.phoneNo}</p>}

        <input
          className="register-reader-input"
          type="text"
          name="city"
          placeholder="City"
          value={formData.city}
          onChange={handleChange}
        />
        {errors.city && <p className="register-reader-error">{errors.city}</p>}

        <input
          className="register-reader-input"
          type="text"
          name="location"
          placeholder="Area"
          value={formData.location}
          onChange={handleChange}
        />
        {errors.location && <p className="register-reader-error">{errors.location}</p>}

        <button className="register-reader-btn" type="submit">Register</button>
      </form>

      {message && <p className="register-reader-message">{message}</p>}
    </div>
  );
}
