import React, { useState } from 'react';
import IssueBooksData from './IssueBooksData';
import RegisterIssueBook from './RegisterIssueBook';
import "./IssueBooks.css"; // new CSS file

export default function BookIssue() {
  const [activeComponent, setActiveComponent] = useState("");

  return (
    <div className="book-issue-container">
      <h2 className="book-issue-title">📚 Manage Book Issues</h2>

      <button
        className="book-issue-btn"
        onClick={() => setActiveComponent('IssueBook')}>
        📖 Issued Books
      </button>

      <button
        className="book-issue-btn"
        onClick={() => setActiveComponent('Register')}>
        📝 Issue
      </button>

      <div className="book-issue-content">
        {activeComponent === 'IssueBook' && <IssueBooksData />}
        {activeComponent === 'Register' && <RegisterIssueBook />}
        {!activeComponent && <p>Select an action above.</p>}
      </div>
    </div>
  );
}
