import React, { useState, useEffect } from "react";
import "./RegisterIssueBook.css";

export default function RegisterIssueBook() {
  const [formData, setFormData] = useState({
    readerId: "",
    bookId: "",
  });

  const [books, setBooks] = useState([]);
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState({});

  // Fetch all books on component mount
  const fetchBooks = async () => {
      try {
        const token = sessionStorage.getItem("token");
        const res = await fetch("http://localhost:8080/api/books", {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          setBooks(data);
        } else {
          setMessage("Failed to fetch books");
        }
      } catch (err) {
        setMessage("Error fetching books: " + err.message);
      }
    };

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => ({ ...prev, [e.target.name]: "" }));
  };

  const validate = () => {
    const errs = {};
    if (!formData.readerId.trim()) errs.readerId = "Reader ID is required";
    if (!formData.bookId.trim()) errs.bookId = "Book ID is required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    if (!validate()) {
      setMessage("Please provide all the values");
      return;
    }

    // Check if book exists and has count > 0
   const book = books.find((b) => String(b.bookID || b.bookId) === formData.bookId.trim());
    if (!book) 
    {
      setMessage("Book ID not found");
      return;
    }
    // console.log("kkkkkkkkkkkkkkkkkkkkkkkkkk")
    if (book.bookCount<= 0)
    {
      // console.log("llllllllllllll");
      setMessage("Book not available");
      return;
    }

    // Proceed to issue book
    try {
      const token = sessionStorage.getItem("token");

      const response = await fetch("http://localhost:8080/librarian/issueBook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          readerId: formData.readerId,
          bookId: formData.bookId,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setMessage(`Book issued successfully. Issue ID: ${data.issueId}`);
        setFormData({ readerId: "", bookId: "" });
        setErrors({});
        await fetchBooks();
      } 
      else if (response.status === 401)
      {
        setMessage("Unauthorized. Please login again.");
      }
      else
      {
        const data=await response.json();
        setMessage(data.error ||"Book not Available right now!!!");
      }
    } 
    catch (error)
    {
      setMessage("Error Occured while performing Action");
    }
  };

  return (
    <div className="register-book-container">
      <h2 className="register-book-title">Issue Book</h2>
      <form className="register-book-form" onSubmit={handleSubmit} noValidate>
        <input
          className="register-book-input"
          type="text"
          name="readerId"
          placeholder="Reader ID"
          value={formData.readerId}
          onChange={handleChange}
        />
        {errors.readerId && <p className="register-book-error">{errors.readerId}</p>}
        <input
          className="register-book-input"
          type="text"
          name="bookId"
          placeholder="Book ID"
          value={formData.bookId}
          onChange={handleChange}
        />
        {errors.bookId && <p className="register-book-error">{errors.bookId}</p>}
    
        <button className="register-book-btn" type="submit">Issue Book</button>
      </form>
      {message && <p className="register-book-message">{message}</p>}
    </div>
  );
}
