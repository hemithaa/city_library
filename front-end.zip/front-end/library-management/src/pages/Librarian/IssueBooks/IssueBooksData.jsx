import React, { useState, useEffect } from "react";
import './IssueBooksData.css';

export default function IssuedBooksData() {
  const [issuedBooks, setIssuedBooks] = useState([]);
  const [booksMap, setBooksMap] = useState({});
  const [filter, setFilter] = useState("All");
  const [message, setMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [searchBy, setSearchBy] = useState("bookName"); // bookName or readerId

  const token = sessionStorage.getItem("token");

  const fetchIssuedBooks = async () => {
    try {
      const response = await fetch("http://localhost:8080/librarian/viewIssuedBooks", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        if (response.status === 401) {
          setMessage("Unauthorized: Please log in as a librarian.");
        }
        const errorText = await response.text();
        setMessage(errorText || `HTTP error: ${response.status}`);
        return;
      }

      const data = await response.json();
      setIssuedBooks(data);

      // Fetch book details for each issued book
      const bookIds = data.map(b => b.bookId);
      const uniqueBookIds = [...new Set(bookIds)];

      const bookDetails = {};
      await Promise.all(
        uniqueBookIds.map(id =>
          fetch(`http://localhost:8080/api/books/${id}`, {
            headers: { Authorization: `Bearer ${token}` }
          })
            .then(res => res.json())
            .then(book => {
              bookDetails[id] = { name: book.name, author: book.authorName };
            })
            .catch(() => {
              bookDetails[id] = { name: "N/A", author: "N/A" };
            })
        )
      );
      setBooksMap(bookDetails);

    } catch (err) {
      setMessage("Error fetching issued books: " + err.message);
    }
  };

  useEffect(() => {
    fetchIssuedBooks();
  }, []);

  const markAsReturned = async (issueId) => {
    try {
      const response = await fetch(`http://localhost:8080/librarian/markReturned/${issueId}`, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const errorText = await response.text();
        console.error(errorText || `Failed to update status. Status: ${response.status}`);
        return;
      }
      fetchIssuedBooks();
    } catch (err) {
      setMessage("Something went wrong");
    }
  };

  // Filter by status
  let filteredBooks = issuedBooks.filter(book => {
    if (filter === "All") return true;
    const today = new Date();
    const returnDate = new Date(book.returnDate);
    const status =
      book.status === "Returned"
        ? "Returned"
        : returnDate < today
        ? "Delayed"
        : "Pending";
    return status === filter;
  });

  // Filter by search term (book name or reader id)
  filteredBooks = filteredBooks.filter(book => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.trim().toLowerCase();
    if (searchBy === "bookName") {
      const bookInfo = booksMap[book.bookId] || { name: "" };
      return bookInfo.name.toLowerCase().includes(term);
    } else {
      return book.readerId.toLowerCase().includes(term);
    }
  });

  return (
    <div className="issued-books-container">
      <h2 className="issued-books-title">Issued Books</h2>

      <div className="issued-books-controls">
        <label>Filter: </label>
        <select
          className="issued-books-filter"
          value={filter}
          onChange={e => setFilter(e.target.value)}
        >
          <option value="All">All</option>
          <option value="Pending">Pending</option>
          <option value="Returned">Returned</option>
          <option value="Delayed">Delayed</option>
        </select>

        <label style={{ marginLeft: "20px" }}>Search by: </label>
        <select
          className="issued-books-filter"
          value={searchBy}
          onChange={e => setSearchBy(e.target.value)}
        >
          <option value="bookName">Book Name</option>
          <option value="readerId">Reader ID</option>
        </select>

        <input
          type="text"
          placeholder={`Enter ${searchBy === "bookName" ? "Book Name" : "Reader ID"}`}
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="issued-books-search"
          style={{ marginLeft: "10px" }}
        />
      </div>

      {message && <p className="issued-books-message">{message}</p>}

      <table className="issued-books-table">
        <thead>
          <tr>
            <th>Reader ID</th>
            <th>Book Name</th>
            <th>Author</th>
            <th>Issue Date</th>
            <th>Expected Return Date</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredBooks.length === 0 && (
            <tr>
              <td colSpan="7" style={{ textAlign: "center" }}>
                No issued books found.
              </td>
            </tr>
          )}
          {filteredBooks.map(book => {
            const bookInfo = booksMap[book.bookId] || { name: "N/A", author: "N/A" };
            const today = new Date();
            const returnDate = new Date(book.returnDate);
            const status =
              book.status === "Returned"
                ? "Returned"
                : returnDate < today
                ? "Delayed"
                : "Pending";

            return (
              <tr key={book.issueId}>
                <td>{book.readerId}</td>
                <td>{bookInfo.name}</td>
                <td>{bookInfo.author}</td>
                <td>{new Date(book.borrowDate).toLocaleDateString()}</td>
                <td>{returnDate.toLocaleDateString()}</td>
                <td>{status}</td>
                <td>
                  {(status === "Pending" || status === "Delayed") && (
                    <button onClick={() => markAsReturned(book.issueId)}>
                      Mark as Returned
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
