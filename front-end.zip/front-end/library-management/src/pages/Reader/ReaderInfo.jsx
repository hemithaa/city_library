import React, { useState, useEffect } from "react";
import './ReaderInfo.css';

export default function ReaderInfo() {
  const [borrowedBooks, setBorrowedBooks] = useState([]);
  const [filter, setFilter] = useState("All");
  const [booksMap, setBooksMap] = useState({});
  const [searchTerm, setSearchTerm] = useState(""); // New search state

  const token = sessionStorage.getItem("token");
  const readerId = sessionStorage.getItem("id");

  useEffect(() => {
    if (!readerId || !token) {
      console.error("Reader ID or token missing");
      return;
    }

    fetch(`http://localhost:8080/librarian/getIssuedBook/${readerId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch borrowed books");
        return res.json();
      })
      .then(async (data) => {
        setBorrowedBooks(data);

        const bookIds = data.map((b) => b.bookId);
        const uniqueBookIds = [...new Set(bookIds)];

        const bookDetails = {};
        await Promise.all(
          uniqueBookIds.map((id) =>
            fetch(`http://localhost:8080/api/books/${id}`, {
              headers: { Authorization: `Bearer ${token}` },
            })
              .then((res) => res.json())
              .then((book) => {
                bookDetails[id] = { name: book.name, author: book.authorName };
              })
              .catch((err) => {
                console.error(`Failed to fetch book ${id}`, err);
                bookDetails[id] = { name: "N/A", author: "N/A" };
              })
          )
        );

        setBooksMap(bookDetails);
      })
      .catch((err) => console.error(err));
  }, [readerId, token]);

  // Apply filter by status
  let filteredBooks = borrowedBooks.filter((book) => {
    if (filter === "All") return true;
    const today = new Date();
    const returnDate = new Date(book.returnDate);
    const status =
      book.status === "Returned"
        ? "Returned"
        : returnDate < today
        ? "Delayed"
        : "Pending";

    return status === filter;
  });

  // Apply search by book name
  filteredBooks = filteredBooks.filter((book) => {
    const bookInfo = booksMap[book.bookId] || { name: "" };
    return bookInfo.name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const booksToReturn = borrowedBooks.filter((b) => b.status !== "Returned").length;

  return (
    <div className="reader-info-container">
      <h2 className="reader-info-title">My Borrowed Books</h2>
      <div className="reader-info-count-box">
        Books to return: <strong>{booksToReturn}</strong>
      </div>

      <div style={{ margin: "15px 0" }}>
        <label>Filter by status: </label>
        <select
          className="reader-info-filter"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="All">All</option>
          <option value="Pending">Pending</option>
          <option value="Returned">Returned</option>
          <option value="Delayed">Delayed</option>
        </select>

        {/* Search by book name */}
        <input
          type="text"
          placeholder="Search by book name"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="reader-info-filter"
          style={{ marginLeft: "15px" }}
        />
      </div>

      <table className="reader-info-table">
        <thead>
          <tr>
            <th>Book Name</th>
            <th>Author Name</th>
            <th>Borrow Date</th>
            <th>Expected Return Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {filteredBooks.length === 0 && (
            <tr>
              <td colSpan="5" style={{ textAlign: "center" }}>
                No borrowed books found.
              </td>
            </tr>
          )}
          {filteredBooks.map((book) => {
            const bookInfo = booksMap[book.bookId] || { name: "N/A", author: "N/A" };
            const today = new Date();
            const returnDate = new Date(book.returnDate);
            const status =
              book.status === "Returned"
                ? "Returned"
                : returnDate < today
                ? "Delayed"
                : "Pending";

            return (
              <tr key={book.issueId}>
                <td>{bookInfo.name}</td>
                <td>{bookInfo.author}</td>
                <td>{new Date(book.borrowDate).toLocaleDateString()}</td>
                <td>{returnDate.toLocaleDateString()}</td>
                <td>{status}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
