import React from "react";
import { Link,Outlet,useLocation } from 'react-router-dom';
export default function ReaderDashboard()
{
    const location = useLocation();
    return (
        <>
      <div className="navbar">
        <div className="listell">
            <Link to="mybooks">My Books</Link>
            <Link to="/Search">Search </Link> 
            <Link to="/" style={{color:"#e74c3c"}} onClick={() => {
                        sessionStorage.removeItem('token');
                        sessionStorage.removeItem('role');
                        }}>Logout
            </Link>
        </div>
      </div>
      
      <div className="content">
        {location.pathname.endsWith("/reader")
        ? (
            <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <h2 style={{ fontSize: '2.5rem', marginBottom: '10px' }}>
                Welcome Reader!
            </h2>
            <p style={{ fontSize: '1.2rem', color: '#555' }}>
                Please select an action from the menu above.
            </p>
        </div>
        ) : (
            <Outlet />
        )}
      </div>
      <br />

      </>
    );
} 