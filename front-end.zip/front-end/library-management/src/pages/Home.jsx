import React from "react";
import "./Home.css";
import { useNavigate, Link } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="home-bg">
      {/* Background image div */}
      <div className="background-image"></div>

      {/* Navigation */}
      <div className="navbar">
        <div className="listell">
          <Link to="/search">🔍 Search</Link>
          <Link to="/login">🔑 Login</Link>
        </div>
      </div>

      {/* Main content container */}
      <div className="container" id="home">
        <div className="left" id="vantaeffect">
          <h1 className="headline-animate">Library Management System</h1>
          <p id="animated-text">Smart. Secure. Effortless.</p>
          <button className="cta-button" onClick={() => navigate('/signup')}>
            Sign Up
          </button>
        </div>
      </div>

      {/* About section */}
      <section className="about-section glass-card">
        <h2>✨ About Library Management System</h2>
        <p>
          Welcome to your next-generation library platform! Discover books, track issues, and manage readers with simplicity and speed. 
          Our system is designed to save you time and bring order to your library operations.
        </p>
        <p>
          Enjoy a secure, scalable, and beautiful experience—whether you’re a librarian or a reader.  
          Join us to explore a smarter way to read and manage resources!
        </p>
      </section>
    </div>
  );
}