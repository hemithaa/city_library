import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import "./ReaderSignUp.css";

export default function ReaderSignUp() {
  const [formData, setFormData] = useState({
    readerId: '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState({
    readerId: '',
    password: '',
    confirmPassword: '',
  });
  const [serverMessage, setServerMessage] = useState('');
  const [messageType, setMessageType] = useState(''); 

  const validateField = (name, value) => {
    let error = '';

    if (!value.trim()) {
      error = `${name === 'readerId' ? 'Reader ID' : name === 'password' ? 'Password' : 'Confirm Password'} is required`;
    }

    if (name === 'confirmPassword' && value !== formData.password) {
      error = 'Passwords do not match';
    }

    if (name === 'password' && formData.confirmPassword) {
      if (value !== formData.confirmPassword) {
        setErrors(prev => ({ ...prev, confirmPassword: 'Passwords do not match' }));
      } else {
        setErrors(prev => ({ ...prev, confirmPassword: '' }));
      }
    }

    setErrors(prev => ({ ...prev, [name]: error }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    validateField(name, value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = {};
    Object.entries(formData).forEach(([key, val]) => {
      if (!val.trim()) {
        newErrors[key] = `${key === 'readerId' ? 'Reader ID' : key === 'password' ? 'Password' : 'Confirm Password'} is required`;
      }
    });

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      try 
      {
        const existsResponse = await fetch(`http://localhost:8080/readers/exists/${formData.readerId.trim()}`);
        if (!existsResponse.ok) throw new Error("Failed to check Reader ID");
        const exists = await existsResponse.json();

        if (!exists) {
          setServerMessage("Reader ID not found in book issues. Sign-up not allowed.");
          setMessageType('error');
          return;
        }
        const signupResponse = await fetch("http://localhost:8080/api/auth/signUp", { 
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            readerId: formData.readerId.trim(),
            password: formData.password.trim()
          })
        });

        if (signupResponse.ok) {
          const msg = await signupResponse.text();
          setServerMessage(msg);
          setMessageType('success');
          setFormData({ readerId: '', password: '', confirmPassword: '' });
        } else {
          let errorText;
          try {
            const errorJson = await signupResponse.json();
            errorText = errorJson.details || 'Sign-up failed';
          } catch {
            errorText = await signupResponse.text();
          }
          setServerMessage(errorText);
          setMessageType('error');
        }

      } catch (error) {
        setServerMessage("Server error. Please try again.");
        setMessageType('error');
      }
    }
  };

  return (
    <>
      <div>
        <div className="navbar">
          <div className="listell">
            <Link to="/">Home</Link>
          </div>
          <div className='listleft'>
            <Link to="/login">Login</Link>
          </div>
        </div>
      </div>
      <div className="form-wrapper">
        <form onSubmit={handleSubmit} noValidate className="login-form">
          <h2 className="form-title">Sign Up</h2>

          <label className="form-label">Reader ID:</label>
          <input
            type="text"
            name="readerId"
            value={formData.readerId}
            onChange={handleChange}
            className="form-input"
            placeholder="Enter Reader ID"
          />
          <div className="error-space">
            {errors.readerId && <p className="error-signin">{errors.readerId}</p>}
          </div>

          <label className="form-label">Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="form-input"
            placeholder="Enter Password"
          />
          <div className="error-space">
            {errors.password && <p className="error-signin">{errors.password}</p>}
          </div>

          <label className="form-label">Confirm Password:</label>
          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            className="form-input"
            placeholder="Re-enter Password"
          />
          <div className="error-space">
            {errors.confirmPassword && (
              <p className="error-signin">{errors.confirmPassword}</p>
            )}
          </div>

          <button type="submit" className="submit-btn">Sign Up</button>

          {serverMessage && (
            <p
              style={{
                color: messageType === 'success' ? 'green' : 'red',
                marginTop: '10px',
                textAlign: 'center'
              }}
            >
              {serverMessage}
            </p>
          )}
        </form>
      </div>
    </>
  );
}
