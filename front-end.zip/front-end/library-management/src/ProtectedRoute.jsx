import React from "react";
import { Navigate } from "react-router-dom";

export default function ProtectedRoute(props) 
{
  const allowedRole = props.allowedRole; // get allowed role
  const children = props.children; 
  const role = sessionStorage.getItem("role");

  if (!role) {
    return <Navigate to="/login" />;
  }

  if (role !== allowedRole) {
    return (
      <p style={{ color: "red", textAlign: "center", marginTop: "20px" }}>
        Access denied. You must be a {allowedRole} to access it.
      </p>
    );
  }

  return children;
}