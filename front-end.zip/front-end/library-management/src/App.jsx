import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Login from "./pages/Login.jsx";
import LibrarianDashboard from './pages/Librarian/LibrarianDashboard'; 
import Book from './pages/Librarian/Books/Book';
import IssueBooks from './pages/Librarian/IssueBooks/IssueBooks';
import RegisterReader from './pages/Librarian/RegisterReader/RegisterReader';
import ReaderInfo from './pages/Reader/ReaderInfo';
import ReaderSignUp from './pages/ReaderSignUp';
import Search from './pages/Search.jsx';
import ReaderDashboard from './pages/Reader/ReaderDashBoard.jsx';
import ProtectedRoute from './ProtectedRoute.jsx';
import ReaderOperations from './pages/Librarian/RegisterReader/ReaderOperations.jsx'
function App()
{
      return(
            <BrowserRouter>
                  <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/login" element={<Login/>} />
                        <Route path="/search" element={<Search/>}/>
                        <Route path="/librarian" element={
                                          <ProtectedRoute allowedRole="LIBRARIAN">
                                                <LibrarianDashboard />
                                          </ProtectedRoute>}>
                              <Route path="Book" element={<Book/>}/>
                              <Route path="IssueBooks" element={<IssueBooks/>}/>
                              <Route path="Register" element={<ReaderOperations/>}/>
                        </Route>
                        <Route path="/reader" element={
                                          <ProtectedRoute allowedRole="READER">
                                                <ReaderDashboard />
                                          </ProtectedRoute>}>
                              <Route path="mybooks" element={<ReaderInfo/>}/>
                        </Route>
                        <Route path="/signUp" element={<ReaderSignUp/>}/>
                  </Routes>
            </BrowserRouter>
      );
}
export default App
